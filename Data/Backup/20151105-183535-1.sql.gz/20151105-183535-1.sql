-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : o260c1105
-- 
-- Part : #1
-- Date : 2015-11-05 18:35:35
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;

